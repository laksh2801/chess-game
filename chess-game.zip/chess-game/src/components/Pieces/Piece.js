import React from 'react';
import './Piece.css';

const Piece = ({ type, color }) => {
  const pieceSymbols = {
    pawn: color === 'white' ? '♙' : '♟',
    rook: color === 'white' ? '♖' : '♜',
    knight: color === 'white' ? '♘' : '♞',
    bishop: color === 'white' ? '♗' : '♝',
    queen: color === 'white' ? '♕' : '♛',
    king: color === 'white' ? '♔' : '♚',
  };

  return <span className="piece">{pieceSymbols[type]}</span>;
};

export default Piece;
