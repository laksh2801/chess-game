import React from 'react';
import Square from '../Square/Square';
import './Board.css';

const Board = ({ boardState, handleMove }) => {
  return (
    <div className="board">
      {boardState.map((row, rowIndex) =>
        row.map((piece, colIndex) => (
          <Square
            key={`${rowIndex}-${colIndex}`}
            position={{ row: rowIndex, col: colIndex }}
            piece={piece}
            onMove={handleMove}
          />
        ))
      )}
    </div>
  );
};

export default Board;
