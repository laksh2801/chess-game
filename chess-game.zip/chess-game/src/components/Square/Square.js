import React from 'react';
import './Square.css';
import Piece from '../Pieces/Piece';

const Square = ({ position, piece, onMove }) => {
  const isDark = (position.row + position.col) % 2 === 1;

  return (
    <div
      className={`square ${isDark ? 'dark' : 'light'}`}
      onClick={() => onMove(position)}
    >
      {piece && <Piece type={piece.type} color={piece.color} />}
    </div>
  );
};

export default Square;
