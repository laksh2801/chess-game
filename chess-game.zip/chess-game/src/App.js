import React, { useState } from 'react';
import Board from './components/Board/Board';
import './App.css';

const initialBoardState = () => {
  const emptyRow = Array(8).fill(null);
  const initialBoard = Array(8).fill([...emptyRow]);

  // Place pawns
  initialBoard[1] = Array(8).fill({ type: 'pawn', color: 'black' });
  initialBoard[6] = Array(8).fill({ type: 'pawn', color: 'white' });

  // Place other pieces
  initialBoard[0] = [
    { type: 'rook', color: 'black' },
    { type: 'knight', color: 'black' },
    { type: 'bishop', color: 'black' },
    { type: 'queen', color: 'black' },
    { type: 'king', color: 'black' },
    { type: 'bishop', color: 'black' },
    { type: 'knight', color: 'black' },
    { type: 'rook', color: 'black' }
  ];

  initialBoard[7] = [
    { type: 'rook', color: 'white' },
    { type: 'knight', color: 'white' },
    { type: 'bishop', color: 'white' },
    { type: 'queen', color: 'white' },
    { type: 'king', color: 'white' },
    { type: 'bishop', color: 'white' },
    { type: 'knight', color: 'white' },
    { type: 'rook', color: 'white' }
  ];

  return initialBoard;
};

function App() {
  const [boardState, setBoardState] = useState(initialBoardState());
  const [selectedSquare, setSelectedSquare] = useState(null);

  const handleMove = (position) => {
    const { row, col } = position;

    if (selectedSquare) {
      const newBoardState = boardState.map((r) => [...r]);
      newBoardState[row][col] = boardState[selectedSquare.row][selectedSquare.col];
      newBoardState[selectedSquare.row][selectedSquare.col] = null;
      setBoardState(newBoardState);
      setSelectedSquare(null);
    } else if (boardState[row][col]) {
      setSelectedSquare({ row, col });
    }
  };

  return (
    <div className="app">
      <h1>Chess Game</h1>
      <Board boardState={boardState} handleMove={handleMove} />
    </div>
  );
}

export default App;
